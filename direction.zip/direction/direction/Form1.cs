﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;


using System.Drawing.Imaging;
using HalconDotNet;



namespace direction
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        int g_length = 0;
        FileInfo[] sortList;//  System.IO
        int g_num = 0;
        //测量
        public static int x0pre;
        public static int y0pre;

        bool next;//下一张
        public static int filenamenum;
        public static string Item_Name = "";
        public static string caption;
        Bitmap SrcImage = null;

        public List<double> t1 = new List<double>();
        public List<double> t2 = new List<double>();
        public List<double> t3 = new List<double>();
        public List<double> t4 = new List<double>();
        public List<double> t5 = new List<double>();
        public List<double> t6 = new List<double>();

        string imagepath;/////图片路径
        HDevelopExport hd = new HDevelopExport();

        private Bitmap show_pic(string s)//read picture from dialog
        {
            FileStream fs = new FileStream(s, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
            Bitmap image = (Bitmap)Image.FromStream(fs);
            fs.Dispose();
            fs.Close();
            return image;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            g_num = 0;
            g_length = 0;
            //string a = "G:\\学习\\梯度方向图片";
            string a = "E:\\戚谢鑫\\学习\\瓶盖项目相关\\caps\\图片\\二维码\\qr\\新建文件夹 (2)";
            
            DirectoryInfo dirinfo = new DirectoryInfo(a);
            sortList = dirinfo.GetFiles();
            string name1 = a + "\\" + sortList[0].ToString();
            //hd.readimage(hWindowControl1.HalconWindow, name1);
            SrcImage = show_pic(name1);
            pictureBox1.Image = SrcImage;
            hd.ho_Image3 = bitmap2hobject(SrcImage);
            HOperatorSet.DispObj(hd.ho_Image3, hWindowControl1.HalconWindow);
            g_length = sortList.Length;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            g_num++;
            if (g_num > g_length - 1)
            {
                g_num = 0;
            }
            //string a = "G:\\学习\\梯度方向图片";

            string a = "E:\\戚谢鑫\\学习\\瓶盖项目相关\\caps\\图片\\二维码\\qr\\新建文件夹 (2)";

            string name1 = a + "\\" + sortList[g_num].ToString();
            SrcImage = show_pic(name1);
            //hd.readimage(hWindowControl1.HalconWindow, name1);
            pictureBox1.Image = SrcImage;
            hd.ho_Image3 = bitmap2hobject(SrcImage);
            HOperatorSet.DispObj(hd.ho_Image3, hWindowControl1.HalconWindow);
            button6_Click(sender, e);
            button7_Click(sender, e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            g_num--;
            if (g_num < 1)
            {
                g_num = g_length-1;
            }
            //string a = "G:\\学习\\梯度方向图片";

            string a = "E:\\戚谢鑫\\学习\\瓶盖项目相关\\caps\\图片\\二维码\\qr\\新建文件夹 (2)";

            string name1 = a + "\\" + sortList[g_num].ToString();
            SrcImage = show_pic(name1);
            hd.readimage(hWindowControl1.HalconWindow, name1);
            pictureBox1.Image = SrcImage;
            button6_Click(sender, e);
        }

        public Bitmap direction(Bitmap b, out double k)
        {
            int w = b.Width;
            int h = b.Height;
            t1.Clear();
            t2.Clear();
            t3.Clear();
            t4.Clear();
            t5.Clear();
            t6.Clear();
            Bitmap tmp = new Bitmap(b);
            BitmapData tmpdata = tmp.LockBits(new Rectangle(0, 0, w, h),
                ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
            double gx = 0.0, gy = 0.0;////x,y方向的梯度
            double sumx = 0, sumy = 0, sumy2 = 0;
            double theta;////梯度方向
            double alfa; ///累计得出的实际方向
            unsafe
            {
                int stride = tmpdata.Stride;
                int offset = stride - 4 * w;
                byte* p0 = (byte*)tmpdata.Scan0;
                //p0 = p0 + (x2 + x1) * 2 + (y2 + y1) / 2 * stride - 16 * 4 - 16 * stride;////取样窗口第一个点
                p0 = p0 + 15 * 4 + 14 * stride;

                byte* p;///网格的第一个点
                byte* p1, p2, p3, p4, p5, p6, p7, p8, pc;
                //////////////\\\\\\\\\\\\\\\\
                /////   p1   p2   p3     \\\\\
                /////                    \\\\\
                /////   p4   pc   p5     \\\\\
                /////                    \\\\\
                /////   p6   p7   p8     \\\\\
                //////////////\\\\\\\\\\\\\\\\

                for (int i = 0; i < 32; i = i + 4)
                {
                    for (int j = 0; j < 32; j = j + 4)
                    {
                        p = p0 + j * 4 + i * stride;
                        //p[2] = 255;
                        for (int m = 0; m < 4; m++)
                        {
                            for (int n = 0; n < 4; n++)
                            {
                                pc = p + n * 4 + m * stride;

                                pc[2] = 255;
                                pc[1] = 0;
                                //显示取样区域

                                p1 = pc - 4 - stride;
                                p2 = p1 + 4;
                                p3 = p2 + 4;
                                p4 = pc - 4;
                                p5 = pc + 4;
                                p6 = pc - 4 + stride;
                                p7 = p6 + 4;
                                p8 = p7 + 4;
                                gx = p3[0] - p1[0] + 2 * (p5[0] - p4[0]) + p8[0] - p6[0];
                                gy = p6[0] - p1[0] + 2 * (p7[0] - p2[0]) + p8[0] - p3[0];
                                sumy = sumy + gx * gx - gy * gy;
                                sumy2 = sumy2 + gy * gy;
                                sumx = sumx + gx * gy;
                                //if (gx == 0)
                                //{
                                //    theta = 90;
                                //}
                                //else
                                //{
                                //    theta = (Math.Atan(gy / gx)) / Math.PI * 180;
                                //}
                                //if (theta < 0)
                                //{
                                //    theta = theta + 90;
                                //}
                                //angelhis(theta);
                            }
                        }
                        if (sumx == 0)
                        {
                            theta = 90;
                        }
                        else
                        {
                            //theta = Math.Atan(sumy / sumx) / 2 * 180 / Math.PI;
                            theta = Math.Atan(sumy2 / sumx) * 180 / Math.PI;
                        }
                        if (theta < 0)
                        {
                            theta = theta + 90;
                        }
                        angelhis(theta);
                    }
                }
                alfa = finddrc();
                k = Math.Tan(alfa * Math.PI / 180);
            }
            tmp.UnlockBits(tmpdata);
            textBox1.Text = alfa.ToString();
            return tmp;
            
        }


        public void angelhis(double theta)
        {
            int flag = 0;
            if (theta >= 0 && theta < 15)
            {
                flag = 1;
            }
            if (theta >= 15 && theta < 30)
            {
                flag = 2;
            }
            if (theta >= 30 && theta < 45)
            {
                flag = 3;
            }
            if (theta > 45 && theta < 60)
            {
                flag = 4;
            }
            if (theta >= 60 && theta < 75)
            {
                flag = 5;
            }
            if (theta >= 75 && theta <= 90)
            {
                flag = 6;
            }
            switch (flag)
            {
                case 1: t1.Add(theta); break;
                case 2: t2.Add(theta); break;
                case 3: t3.Add(theta); break;
                case 4: t4.Add(theta); break;
                case 5: t5.Add(theta); break;
                case 6: t6.Add(theta); break;
            }
        }
        public double finddrc()
        {
            double theta = 0;
            int[] l = new int[6];
            l[0] = t1.Count;
            l[1] = t2.Count;
            l[2] = t3.Count;
            l[3] = t4.Count;
            l[4] = t5.Count;
            l[5] = t6.Count;
            int max = 0;
            int flag = 0;
            double sum = 0;
            for (int i = 0; i < 6; i++)
            {
                if (l[i] > max)
                {
                    max = l[i];
                    flag = i;
                }
            }
            switch (flag)
            {
                case 0:
                    for (int i = 0; i < l[0]; i++)
                    {
                        sum = sum + t1[i];
                    }
                    theta = sum / l[0];
                    break;
                case 1:
                    for (int i = 0; i < l[1]; i++)
                    {
                        sum = sum + t2[i];
                    }
                    theta = sum / l[1];
                    break;
                case 2:
                    for (int i = 0; i < l[2]; i++)
                    {
                        sum = sum + t3[i];
                    }
                    theta = sum / l[2];
                    break;
                case 3:
                    for (int i = 0; i < l[3]; i++)
                    {
                        sum = sum + t4[i];
                    }
                    theta = sum / l[3];
                    break;
                case 4:
                    for (int i = 0; i < l[4]; i++)
                    {
                        sum = sum + t5[i];
                    }
                    theta = sum / l[4];
                    break;
                case 5:
                    for (int i = 0; i < l[5]; i++)
                    {
                        sum = sum + t6[i];
                    }
                    theta = sum / l[5];
                    break;
            }
            return theta;
        }

        public void drawdirection(Bitmap b)
        {
            double k;
            double x,x2;
            double y,y2;
            Bitmap tmp = new Bitmap(b);
            Bitmap tmp2 = direction(tmp, out k);
            pictureBox1.Image = tmp2;
            Graphics g = Graphics.FromImage(tmp);
            Pen pen = new Pen(Color.Red);
            int w = b.Width;
            int h = b.Height;
            if (k >= 0 && k <= 1)
            {
                x = tmp.Width;
                y = k * x;
                x2 = k * h;
                g.DrawLine(pen, 0, 0, w, (int)y);
                g.DrawLine(pen, 0, h, (int)x2, 0);
            }
            else
            {
                if (k < 0 && k > -1)
                {
                    x = 0;
                    y = -k * w;
                    x2 = -k * h;
                    g.DrawLine(pen, w, 0, 0, (int)y);
                    g.DrawLine(pen, 0, 0, (int)x2, h);
                }
                if (k <= -1)
                {
                    x = h / (-k);
                    y2 = w / (-k);
                    g.DrawLine(pen, 0, h, (int)x, 0);
                    g.DrawLine(pen, 0, 0, w, (int)y2);
                }
                else
                {
                    x = h / k;
                    y2 = w / k;
                    g.DrawLine(pen, 0, 0, (int)x, h);
                    g.DrawLine(pen, 0, (int)y2, w, 0);
                }
            }
            g.Save();
            g.Dispose();
            pictureBox2.Image = tmp;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Bitmap tmp = new Bitmap((Bitmap)SrcImage.Clone());
            drawdirection(tmp);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofdlg = new OpenFileDialog();
            ofdlg.Title = "打开图像文件";
            ofdlg.Filter = "bmp file(*.bmp)|*.bmp|all file(*.*)|*.*";
            if (ofdlg.ShowDialog() == DialogResult.OK)
            {
                FileStream fs = new FileStream(ofdlg.FileName, FileMode.Open);
                imagepath = ofdlg.FileName;
                hd.readimage(hWindowControl1.HalconWindow, imagepath);
            }
                //image = (Bitmap)Image.FromStream(fs);
                //org = image;
                //fs.Dispose();
                //fs.Close();
                //pictureBox.Image = image;
                //odb1 = new Bitmap(image);
                //odb1 = new Bitmap(image);
            //hd.readimage(hWindowControl1.HalconWindow, imagepath);
           // hd.RunHalcon(hWindowControl1.HalconWindow);
            //label1.Text = hd.hv_DecodedDataStrings.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            sw.Reset();
            sw.Start();
            hd.decode();
            sw.Stop();

            label1.Text = hd.hv_DecodedDataStrings.ToString();
            label2.Text = "耗时：" + sw.ElapsedMilliseconds.ToString() + "ms";

            //bitmap2hobject();
        }

        public HObject bitmap2hobject(Bitmap bMap)
        {
            //Bitmap bMap = new Bitmap("E:/戚谢鑫/学习/瓶盖项目相关/caps/图片/二维码/qr/新建文件夹 (3)/DEF_0002.BMP");
            Bitmap tmp = rgb2gray(bMap);
            Rectangle rect = new Rectangle(0, 0, bMap.Width, bMap.Height);
            BitmapData bitmapData = tmp.LockBits(rect, ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
            HObject img;
            HOperatorSet.GenImage1(out img, "byte", bMap.Width, bMap.Height, bitmapData.Scan0);
            tmp.UnlockBits(bitmapData);
            HOperatorSet.DispObj(img, hWindowControl1.HalconWindow);
            return img;
        }

        public Bitmap rgb2gray(Bitmap b)
        {
            Bitmap dst = new Bitmap(b);
            BitmapData bdata = b.LockBits(new Rectangle(0, 0, b.Width, b.Height),
                ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
            BitmapData dstdata = dst.LockBits(new Rectangle(0, 0, dst.Width, dst.Height),
                ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
            unsafe
            {
                byte* p0 = (byte*)bdata.Scan0;
                byte* p1 = (byte*)dstdata.Scan0;
                int offset = bdata.Stride - 4 * bdata.Width;
                for (int i=0;i<b.Height;i++)
                {
                    for(int j=0;j<bdata.Width;j++)
                    {
                        p1[0] = p0[0];
                        p0 = p0 + 4;
                        p1 ++;
                    }
                    p0 = p0 + offset;
                    p1 = p1 + offset;
                }
            }
            b.UnlockBits(bdata);
            dst.UnlockBits(dstdata);
            return dst;
        }

        private void hWindowControl1_HMouseMove(object sender, HalconDotNet.HMouseEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            sw.Reset();
            sw.Start();

            Task[] tasks = new Task[1];
            tasks[0] = Task.Factory.StartNew(() =>
               {
                   hd.decode();
               });
            Task.WaitAll (tasks,30);

            sw.Stop();
            if(tasks [0].Status!=TaskStatus.RanToCompletion)
            {
                label3.Text = "无法解码";
                label4.Text = "耗时：" + sw.ElapsedMilliseconds.ToString() + "ms";
            }
            else
            {
                label3.Text = hd.hv_DecodedDataStrings.ToString();
                label4.Text = "耗时：" + sw.ElapsedMilliseconds.ToString() + "ms";
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

    }
}
